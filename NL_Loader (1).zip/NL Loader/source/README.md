# NL Loader

Воссозданный интерфейс лоадера neverlose.cc на Win32, Direct3D 11 и Dear ImGui (C++20).

[![C++20](https://img.shields.io/badge/C%2B%2B-20-00599C?logo=cplusplus&logoColor=white)](https://isocpp.org/)
[![DirectX 11](https://img.shields.io/badge/DirectX-11-107C10?logo=windows&logoColor=white)](https://learn.microsoft.com/windows/win32/direct3d11/)
[![Dear ImGui](https://img.shields.io/badge/UI-Dear%20ImGui-1F6FEB)](https://github.com/ocornut/imgui)
[![CMake](https://img.shields.io/badge/Build-CMake-064F8C?logo=cmake&logoColor=white)](https://cmake.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

> [!NOTE]
> Независимый учебный UI-проект. Не связан с neverlose.cc и не одобрен им. В игры ничего не внедряется: экран загрузки — только анимация.

| Дашборд | Окно игры |
| --- | --- |
| ![Дашборд](docs/dashboard.png) | ![Окно игры](docs/modal.png) |

## Возможности

- Подписки читаются из JSON и проверяются в реальном времени: если подписка истекает при открытом окне игры, окно закрывается, а карточка блокируется.
- Активные подписки идут первыми, неактивная карточка плавно уезжает вниз.
- Выбор ветки сборки и список изменений.
- Видеофон и анимированные переходы.
- Логика (разбор JSON, сохранение, форматирование, скролл, анимации) не зависит от Win32 и покрыта юнит-тестами.

## Запуск

Запусти `NL.exe`. Рядом с ним должен лежать `background.mp4` — видеофон окна (без него окно откроется без видео).

Вход: логин `OWNER`, пароль `1234`.

Список продуктов встроен в exe (`data/cheats.json`). В `%LOCALAPPDATA%\NLLoader\cheats.json` сохраняются только выбранная ветка и время последнего запуска.

## Сборка

Нужны Windows 10/11 x64, CMake 3.25+ и один из компиляторов.

**Visual Studio 2022** (с Windows SDK):

```powershell
cmake --workflow --preset msvc
```

Результат: `build\msvc\Release\NL.exe`.

**MinGW-w64, GCC 13+** (папка `bin` должна быть в `PATH`):

```powershell
cmake --workflow --preset mingw
```

Результат: `build\mingw\NL.exe`.

`background.mp4` копируется рядом с exe автоматически.

## Тесты

Логика собирается и тестируется на любой ОС с компилятором C++20 (GCC 13+, Clang 17+, MSVC 2022):

```bash
cmake --workflow --preset tests
```

С Visual Studio тесты запускаются сразу в `--preset msvc`.

## Структура

```text
src/             код приложения
  ui/            дашборд, окно игры, вход, тема, скролл, видеофон
  generated/     встроенные картинки, шрифты и шейдеры (генерируются, руками не править)
res/             картинки, видео, ресурсы exe (версия, манифест)
data/            cheats.json по умолчанию
tests/           юнит-тесты (doctest)
tools/           генераторы для src/generated
vendor/          Dear ImGui, nlohmann/json, stb_image, doctest, шрифт Inter
docs/            скриншоты
```

После замены ресурсов перегенерируй файлы в `src/generated`:

| Что поменял | Команда |
| --- | --- |
| картинки в `res/` или `data/cheats.json` | `python tools/gen_embedded.py` |
| шрифты в `vendor/fonts/inter/` | `python tools/gen_fonts.py` |
| шейдеры (исходники внутри `tools/bake_shaders.cpp`) | собрать `bake_shaders` (MSVC) и запустить `bake_shaders src/generated/ImGuiShaders.h` |

## Лицензия

[MIT](LICENSE). Сторонние компоненты и шрифты — в [NOTICE](NOTICE).
