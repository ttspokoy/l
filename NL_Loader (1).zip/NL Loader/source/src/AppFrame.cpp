#include "AppFrame.h"
#include "Fonts.h"
#include "Log.h"
#include "Win32Util.h"
#include "ui/UiGpuResources.h"
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <algorithm>
#include <array>
#include <ctime>
#include <filesystem>
#include <string>

namespace nl {

namespace {

std::wstring FindBackgroundVideo() {
    wchar_t exePath[MAX_PATH]{};
    if (GetModuleFileNameW(nullptr, exePath, MAX_PATH) > 0) {
        const std::filesystem::path dir = std::filesystem::path(exePath).parent_path();
        for (const auto& candidate :
             {dir / L"background.mp4", dir / L"res" / L"background.mp4"}) {
            std::error_code ec;
            if (std::filesystem::exists(candidate, ec)) return candidate.wstring();
        }
    }
    std::error_code ec;
    for (const auto& candidate :
         {std::filesystem::path(L"background.mp4"), std::filesystem::path(L"res/background.mp4")}) {
        if (std::filesystem::exists(candidate, ec))
            return std::filesystem::absolute(candidate, ec).wstring();
    }
    return {};
}

} // namespace

bool AppFrame::WantCaptureMouse() const {
    if (!imguiReady_) return false;
    return ImGui::IsAnyItemHovered() || ImGui::IsAnyItemActive();
}

void AppFrame::InitClock() {
    QueryPerformanceFrequency(&qpcFreq_);
    QueryPerformanceCounter(&qpcLast_);
}

void AppFrame::ConfigureBootAnim(int splashSize, int targetW, int targetH) {
    anim_.winW = splashSize;
    anim_.winH = splashSize;
    anim_.targetW = targetW;
    anim_.targetH = targetH;
}

void AppFrame::InitFonts() {
    ImGuiIO& io = ImGui::GetIO();
    ImFontConfig cfg;
    cfg.FontDataOwnedByAtlas = false;

    // Latin-1 plus general punctuation, so dashes and quotes in changelogs render.
    static constexpr ImWchar kGlyphRanges[] = {0x0020, 0x00FF, 0x2010, 0x2027, 0};
    auto addFont = [&](const unsigned char* data, size_t size, float px) -> ImFont* {
        if (!data || size == 0) return nullptr;
        return io.Fonts->AddFontFromMemoryTTF(const_cast<void*>(static_cast<const void*>(data)),
                                              static_cast<int>(size), px, &cfg, kGlyphRanges);
    };

    theme_.fontDefault = addFont(UI_FONT_REGULAR, UI_FONT_REGULAR_SIZE, 17.f);
    theme_.fontSmall = addFont(UI_FONT_REGULAR, UI_FONT_REGULAR_SIZE, 13.f);
    if (!theme_.fontDefault) theme_.fontDefault = io.Fonts->AddFontDefault();
    if (!theme_.fontSmall) theme_.fontSmall = theme_.fontDefault;
    io.FontDefault = theme_.fontDefault;

    theme_.fontLogo = addFont(UI_FONT_BOLD, UI_FONT_BOLD_SIZE, 40.f);
    theme_.fontTitle = addFont(UI_FONT_BOLD, UI_FONT_BOLD_SIZE, 20.f);
    theme_.fontModalTitle = addFont(UI_FONT_BOLD, UI_FONT_BOLD_SIZE, 24.f);
    if (!theme_.fontLogo) theme_.fontLogo = theme_.fontDefault;
    if (!theme_.fontTitle) theme_.fontTitle = theme_.fontDefault;
    if (!theme_.fontModalTitle) theme_.fontModalTitle = theme_.fontDefault;
}

void AppFrame::TeardownImGui() {
    imguiReady_ = false;
    if (dx11Backend_) {
        ImGui_ImplDX11_Shutdown();
        dx11Backend_ = false;
    }
    if (win32Backend_) {
        ImGui_ImplWin32_Shutdown();
        win32Backend_ = false;
    }
    if (contextCreated_) {
        ImGui::DestroyContext();
        contextCreated_ = false;
    }
}

void AppFrame::ShutdownGraphics() {
    video_.Shutdown();
    theme_.ClearFonts();
    ui::ReleaseTextures(gpu_);
    TeardownImGui();
}

bool AppFrame::InitImGui(HWND hwnd, AppDevice& device) {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    contextCreated_ = true;
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    ui::ApplyTheme(ImGui::GetStyle(), theme_);
    InitFonts();

    if (!ImGui_ImplWin32_Init(hwnd)) {
        Log("ImGui_ImplWin32_Init failed");
        return false;
    }
    win32Backend_ = true;

    if (!ImGui_ImplDX11_Init(device.Device(), device.Context())) {
        Log("ImGui_ImplDX11_Init failed");
        return false;
    }
    dx11Backend_ = true;
    imguiReady_ = true;
    return true;
}

void AppFrame::LoadResources(AppDevice& device) {
    ui::LoadTextures(gpu_, device.Device(), device.Context());

    videoPath_ = FindBackgroundVideo();
    if (videoPath_.empty()) {
        Log("Background video not found (background.mp4 next to the exe)");
    } else if (!video_.Init(device.Device(), device.Context(), videoPath_)) {
        Log("Background video init failed");
    }
}

bool AppFrame::RecreateGraphics(AppDevice& device, AppWindow& window) {
    Log("Recreating D3D11 device after loss/reset");
    video_.Shutdown();
    ui::ReleaseTextures(gpu_);

    if (dx11Backend_) {
        ImGui_ImplDX11_Shutdown();
        dx11Backend_ = false;
    }
    device.Cleanup();

    if (!device.Init(window.Hwnd(), anim_.targetW, anim_.targetH)) {
        Log("Device recreate failed");
        return false;
    }
    if (imguiReady_) {
        if (!ImGui_ImplDX11_Init(device.Device(), device.Context())) {
            Log("ImGui_ImplDX11_Init failed after recreate");
            return false;
        }
        dx11Backend_ = true;
    }
    ui::LoadTextures(gpu_, device.Device(), device.Context());
    if (!videoPath_.empty() && !video_.Init(device.Device(), device.Context(), videoPath_))
        Log("Background video re-init failed");
    return true;
}

void AppFrame::OpenUrl(const wchar_t* url) {
    if (!OpenHttpsUrl(url)) Log("OpenUrl failed");
}

void AppFrame::ProcessDashActions(const ui::DashActions& act, AppWindow& window,
                                  bool& requestExitAnim) {
    if (act.close) requestExitAnim = true;
    if (act.minimize) {
        ShowWindow(window.Hwnd(), SW_MINIMIZE);
        window.EndDrag();
    }
    if (act.openUrl) OpenUrl(act.openUrl);
}

void AppFrame::SubmitAuth() {
    ui::AuthState& auth = ui_.auth;
    if (auth.checking) return;

    auto trim = [](const char* text) {
        std::string s(text);
        const auto first = s.find_first_not_of(" \t\r\n");
        if (first == std::string::npos) return std::string{};
        const auto last = s.find_last_not_of(" \t\r\n");
        return s.substr(first, last - first + 1);
    };

    const std::string user = trim(auth.username);
    const std::string pass = trim(auth.password);

    if (user.empty() || pass.empty()) {
        auth.error = "Enter your username and password";
        return;
    }
    if (user == "OWNER" && pass == "1234") {
        auth.error.clear();
        auth.checking = true;
        auth.checkStart = static_cast<double>(timeSec_);
        auth.focus = -1;
        ui_.userName = user;
    } else {
        auth.error = "Invalid username or password";
    }
}

void AppFrame::ProcessAuthActions(const ui::AuthActions& act, AppWindow& window) {
    if (act.close || act.requestExit) {
        RequestUserClose(window);
        return;
    }
    if (act.minimize) {
        ShowWindow(window.Hwnd(), SW_MINIMIZE);
        window.EndDrag();
    }
    if (act.openUrl) OpenUrl(act.openUrl);
    if (act.submit) SubmitAuth();
}

void AppFrame::ProcessModalActions(ui::ModalActions& act, time_t now) {
    if (act.openUrl) OpenUrl(act.openUrl);
    if (act.persistLastLaunch) {
        if (auto* c = store_.Find(act.lastLaunchCheatId)) {
            for (auto& b : c->branches) {
                if (b.id == act.lastLaunchBranchId) {
                    b.lastLaunch = act.lastLaunchWhen;
                    break;
                }
            }
            ui::FillDisplayedBranch(ui_, *c, now);
        }
        if (!store_.SaveLastLaunch(act.lastLaunchCheatId, act.lastLaunchBranchId,
                                   act.lastLaunchWhen))
            Log("Failed to persist last launch for {}", act.lastLaunchCheatId);
    }
    if (act.persistSelectedBranch) {
        if (auto* c = store_.Find(act.selectedCheatId)) {
            c->selectedBranch = act.selectedBranchId;
            if (!ui_.modal.open) ui::FillDisplayedBranch(ui_, *c, now);
        }
        if (!store_.SaveSelectedBranch(act.selectedCheatId, act.selectedBranchId))
            Log("Failed to persist selected branch for {}", act.selectedCheatId);
    }
}

void AppFrame::RequestUserClose(AppWindow& window) {
    if (anim_.phase == ui::Phase::Exiting || anim_.exitDone) return;
    exitFromAuth_ = anim_.phase == ui::Phase::Auth || anim_.phase == ui::Phase::AuthOut ||
                    anim_.phase == ui::Phase::Expanding;
    window.EndDrag();
    ui::BeginExit(anim_);
}

void AppFrame::OnDpiChanged(AppDevice& device, UINT dpi, int width, int height) {
    Log("DPI changed: {} ({}x{})", dpi, width, height);
    if (width <= 0 || height <= 0) return;

    if (device.Ready() && !device.Resize(width, height)) {
        Log("Resize after DPI change failed; keeping previous size");
        return;
    }
    anim_.targetW = width;
    anim_.targetH = height;
    anim_.regionDirty = true;
}

void AppFrame::RenderUi(float dt, AppWindow& window) {
    const ui::FrameInput frame{GetTickCount64(), time(nullptr), dt, anim_.targetW, anim_.targetH};

    const bool authPage = anim_.phase == ui::Phase::Auth || anim_.phase == ui::Phase::AuthOut ||
                          (anim_.phase == ui::Phase::Expanding && anim_.contentAlpha > 0.01f) ||
                          (anim_.phase == ui::Phase::Exiting && exitFromAuth_);
    const bool dashPage = (anim_.phase == ui::Phase::Ready && anim_.contentAlpha > 0.01f) ||
                          (anim_.phase == ui::Phase::Exiting && !exitFromAuth_);

    // The animated video background runs on every page; the boot splash keeps it lighter.
    const bool booting = anim_.phase == ui::Phase::Splash || anim_.phase == ui::Phase::Expanding;
    if (video_.Ready()) video_.Tick(timeSec_);
    ui::DrawVideoCover(ImGui::GetBackgroundDrawList(), video_, static_cast<float>(anim_.targetW),
                       static_cast<float>(anim_.targetH), 1.f, booting ? 0.22f : 0.48f);

    if (anim_.loaderAlpha > 0.01f &&
        (anim_.phase == ui::Phase::Splash || anim_.phase == ui::Phase::Expanding)) {
        ui::DrawSplash(theme_, timeSec_, anim_.loaderAlpha);
    }

    if (authPage) {
        ui::AuthActions act{};
        ui::DrawAuth(theme_, ui_, gpu_, anim_.contentAlpha, frame, act);
        ProcessAuthActions(act, window);
    }

    if (dashPage) {
        float dashAlpha = anim_.contentAlpha;
        if (anim_.phase == ui::Phase::Exiting) dashAlpha = std::max(dashAlpha, anim_.windowAlpha);

        ui::DashActions act{};
        ui::DrawDashboard(theme_, ui_, gpu_, store_, dashAlpha, frame, act);
        bool requestClose = false;
        ProcessDashActions(act, window, requestClose);
        if (requestClose) RequestUserClose(window);
    }

    ui::ModalActions modalAct{};
    ui::DrawGameModal(theme_, ui_, gpu_, store_, frame, modalAct);
    ProcessModalActions(modalAct, frame.nowUnix);
    if (ui_.requestExit) {
        ui_.requestExit = false;
        ui::BeginExit(anim_);
    }

    if (ui_.disableDrag) window.EndDrag();

    if (window.IsDragging()) {
        window.DragTo();
        if (!ImGui::IsMouseDown(ImGuiMouseButton_Left)) window.EndDrag();
    }
}

bool AppFrame::TickFrame(AppWindow& window, AppDevice& device, bool& running) {
    if (qpcFreq_.QuadPart == 0) {
        Log("TickFrame: QPC frequency unavailable");
        running = false;
        PostQuitMessage(0);
        return false;
    }

    LARGE_INTEGER now{};
    QueryPerformanceCounter(&now);
    float dt = static_cast<float>(now.QuadPart - qpcLast_.QuadPart) /
               static_cast<float>(qpcFreq_.QuadPart);
    qpcLast_ = now;
    if (dt > 0.05f) dt = 0.05f;
    if (dt < 0.0001f) dt = 0.0001f;
    timeSec_ += dt;

    ui::TickAnim(anim_, dt);

    if (ui_.auth.checking &&
        static_cast<double>(timeSec_) - ui_.auth.checkStart >= 0.85) {
        ui_.auth.checking = false;
        ui_.auth.focus = -1;
        ui_.auth.error.clear();
        if (anim_.phase == ui::Phase::Auth) ui::BeginAuthOut(anim_);
    }

    if (anim_.exitDone) {
        running = false;
        PostQuitMessage(0);
        return false;
    }
    if (anim_.regionDirty) {
        window.ApplyRoundRegion(anim_.targetW, anim_.targetH, anim_.winW, anim_.winH,
                                ui::kCornerRadius);
        anim_.regionDirty = false;
    }

    window.SetLayeredAlpha(static_cast<BYTE>(anim_.windowAlpha * 255.f));

    if (window.IsMinimized() && anim_.phase != ui::Phase::Exiting) {
        WaitMessage();
        return true;
    }

    if (!imguiReady_ || !device.Ready()) {
        Log("Frame skipped: missing rtv/device/imgui");
        running = false;
        PostQuitMessage(0);
        return false;
    }

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    RenderUi(dt, window);
    ImGui::Render();

    const std::array<float, 4> clear = {theme_.bg.x, theme_.bg.y, theme_.bg.z, 1.f};
    device.ClearAndBind(clear);
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

    const PresentResult pr = device.Present(1);
    if (pr == PresentResult::DeviceLost) {
        if (!RecreateGraphics(device, window)) {
            running = false;
            PostQuitMessage(0);
            return false;
        }
    } else if (pr == PresentResult::Failed) {
        Log("Present failed; continuing");
    }
    return true;
}

} // namespace nl
