#pragma once
#include <cstddef>

// Inter Medium / Black, embedded into src/generated/Fonts.cpp by tools/gen_fonts.py.
extern const unsigned char UI_FONT_REGULAR[];
extern const size_t UI_FONT_REGULAR_SIZE;
extern const unsigned char UI_FONT_BOLD[];
extern const size_t UI_FONT_BOLD_SIZE;
