#include "UiState.h"
#include "UiGpuResources.h"
#include "Widgets.h"
#include "Theme.h"
#include "imgui.h"

#include <algorithm>
#include <cfloat>
#include <cstring>

namespace nl::ui {

namespace {

constexpr float kFieldW = 300.f;
constexpr float kFieldH = 38.f;
constexpr float kFieldX0 = 178.f;
constexpr float kFieldX1 = 226.f;
constexpr float kFieldRounding = 8.f;

ImVec2 CenterText(ImFont* font, float size, const char* text) {
    return font->CalcTextSizeA(size, FLT_MAX, 0.f, text);
}

void DrawCentered(ImDrawList* dl, ImFont* font, float size, float centerX, float top,
                  const char* text, ImU32 color) {
    const ImVec2 sz = CenterText(font, size, text);
    dl->AddText(font, size, ImVec2(centerX - sz.x * 0.5f, top), color, text);
}

} // namespace

void DrawAuth(Theme& theme, UiState& ui, const UiGpuResources& gpu, float contentAlpha,
              const FrameInput& frame, AuthActions& out) {
    if (contentAlpha < 0.001f) return;

    ImGuiIO& io = ImGui::GetIO();
    const float winW = static_cast<float>(frame.winW);
    const float winH = static_cast<float>(frame.winH);

    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2(winW, winH));
    ImGui::Begin("##auth", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings |
                     ImGuiWindowFlags_NoBringToFrontOnFocus | ImGuiWindowFlags_NoBackground |
                     ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, contentAlpha);

    // --- logo -------------------------------------------------------------
    constexpr float kLogoSize = 58.f;
    const ImVec2 logoPos((winW - kLogoSize) * 0.5f, 40.f);
    if (gpu.gwLogo) {
        dl->AddImage(reinterpret_cast<ImTextureID>(gpu.gwLogo.Get()), logoPos,
                     ImVec2(logoPos.x + kLogoSize, logoPos.y + kLogoSize), ImVec2(0, 0),
                     ImVec2(1, 1), IM_COL32(255, 255, 255, static_cast<int>(255 * contentAlpha)));
    } else {
        ImFont* logoFont = theme.fontLogo ? theme.fontLogo : theme.fontDefault;
        DrawCentered(dl, logoFont, 34.f, winW * 0.5f, 46.f, "GW",
                     ImGui::GetColorU32(WithAlpha(theme.text, contentAlpha)));
    }

    // --- titles -----------------------------------------------------------
    ImFont* titleFont = theme.fontModalTitle ? theme.fontModalTitle : theme.fontDefault;
    ImFont* smallFont = theme.fontSmall ? theme.fontSmall : theme.fontDefault;
    ImFont* bodyFont = theme.fontDefault;

    DrawCentered(dl, titleFont, 24.f, winW * 0.5f, 116.f, "Sign in",
                 ImGui::GetColorU32(WithAlpha(theme.text, contentAlpha)));
    DrawCentered(dl, smallFont, 13.f, winW * 0.5f, 147.f, "use your account to continue",
                 ImGui::GetColorU32(WithAlpha(theme.textMuted, contentAlpha)));

    const bool checking = ui.auth.checking;
    const float fieldX = (winW - kFieldW) * 0.5f;

    auto drawField = [&](int index, const char* id, const char* hint, char* buffer, int size,
                         ImGuiInputTextFlags flags) {
        const float y = index == 0 ? kFieldX0 : kFieldX1;
        const ImVec2 p0(fieldX, y);
        const ImVec2 p1(fieldX + kFieldW, y + kFieldH);
        const bool focused = ui.auth.focus == index;
        const ImU32 bg = ImGui::GetColorU32(WithAlpha(ImVec4(0.016f, 0.035f, 0.059f, 0.92f),
                                                      contentAlpha));
        const ImU32 border = ImGui::GetColorU32(
            WithAlpha(focused ? theme.accent : theme.cardOutline, contentAlpha));
        dl->AddRectFilled(p0, p1, bg, kFieldRounding);
        dl->AddRect(p0, p1, border, kFieldRounding, 0, 1.5f);

        ImGui::SetCursorScreenPos(ImVec2(p0.x, p0.y + 1.f));
        ImGui::SetNextItemWidth(kFieldW);
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(12.f, 10.f));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, kFieldRounding);
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.f);
        ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_Text, theme.text);
        ImGui::PushStyleColor(ImGuiCol_TextDisabled, theme.textMuted);
        const bool entered =
            ImGui::InputTextWithHint(id, hint, buffer, size,
                                     flags | (checking ? ImGuiInputTextFlags_ReadOnly : 0));
        if (ImGui::IsItemActive()) ui.auth.focus = index;
        ImGui::PopStyleColor(5);
        ImGui::PopStyleVar(3);
        return entered;
    };

    bool submitted = false;
    if (checking) {
        drawField(0, "##username", "Username", ui.auth.username, IM_ARRAYSIZE(ui.auth.username),
                  ImGuiInputTextFlags_None);
        drawField(1, "##password", "Password", ui.auth.password, IM_ARRAYSIZE(ui.auth.password),
                  ImGuiInputTextFlags_Password);
    } else {
        if (drawField(0, "##username", "Username", ui.auth.username,
                      IM_ARRAYSIZE(ui.auth.username), ImGuiInputTextFlags_None))
            submitted = true;
        if (drawField(1, "##password", "Password", ui.auth.password,
                      IM_ARRAYSIZE(ui.auth.password), ImGuiInputTextFlags_Password))
            submitted = true;

        if (!ImGui::IsAnyItemActive() && ImGui::IsMouseClicked(ImGuiMouseButton_Left) &&
            ui.auth.focus >= 0) {
            const ImVec2 mouse = io.MousePos;
            const float y = ui.auth.focus == 0 ? kFieldX0 : kFieldX1;
            if (mouse.x < fieldX || mouse.x > fieldX + kFieldW || mouse.y < y ||
                mouse.y > y + kFieldH)
                ui.auth.focus = -1;
        }
    }

    // --- error ------------------------------------------------------------
    if (!ui.auth.error.empty()) {
        DrawCentered(dl, smallFont, 13.f, winW * 0.5f, 271.f, ui.auth.error.c_str(),
                     ImGui::GetColorU32(WithAlpha(theme.error, contentAlpha)));
    }

    // --- submit button ----------------------------------------------------
    const ImVec2 btnP0(fieldX, 289.f);
    const ImVec2 btnP1(fieldX + kFieldW, 289.f + kFieldH);
    ImGui::SetCursorScreenPos(btnP0);
    ImGui::InvisibleButton("##signin", ImVec2(kFieldW, kFieldH));
    HoverLerp(ui.auth.submitHover, ImGui::IsItemHovered() && !checking, frame.dt);
    if (ImGui::IsItemClicked() && !checking) submitted = true;

    ImVec4 btnColor = theme.button;
    if (checking)
        btnColor = Lerp4(theme.button, theme.cardBg, 0.25f);
    else
        btnColor = Lerp4(theme.button, ImVec4(1, 1, 1, 1), 0.08f * ui.auth.submitHover);
    dl->AddRectFilled(btnP0, btnP1, ImGui::GetColorU32(WithAlpha(btnColor, contentAlpha)), 6.f);
    DrawCentered(dl, bodyFont, 17.f, winW * 0.5f, btnP0.y + 10.f,
                 checking ? "Signing in..." : "Sign in",
                 ImGui::GetColorU32(WithAlpha(theme.text, contentAlpha)));

    // --- create account link ---------------------------------------------
    const char* linkText = "create account";
    const ImVec2 linkSize = CenterText(smallFont, 13.f, linkText);
    const ImVec2 linkPos((winW - linkSize.x) * 0.5f, 342.f);
    ImGui::SetCursorScreenPos(linkPos);
    ImGui::InvisibleButton("##createaccount", linkSize);
    HoverLerp(ui.auth.linkHover, ImGui::IsItemHovered(), frame.dt);
    if (ImGui::IsItemClicked()) out.openUrl = L"https://gamewarecc.vercel.app";
    const ImVec4 linkColor = Lerp4(theme.link, theme.textHover, ui.auth.linkHover);
    dl->AddText(smallFont, 13.f, linkPos,
                ImGui::GetColorU32(WithAlpha(linkColor, contentAlpha)), linkText);
    if (ui.auth.linkHover > 0.02f) {
        dl->AddLine(ImVec2(linkPos.x, linkPos.y + linkSize.y),
                    ImVec2(linkPos.x + linkSize.x, linkPos.y + linkSize.y),
                    ImGui::GetColorU32(WithAlpha(linkColor, contentAlpha)), 1.f);
    }

    // --- window chrome ----------------------------------------------------
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
    ImGui::SetCursorPos(ImVec2(winW - 35.f, 20.f));
    ImGui::InvisibleButton("##authClose", ImVec2(20.f, 20.f));
    HoverLerp(ui.closeHover, ImGui::IsItemHovered(), frame.dt);
    if (ImGui::IsItemClicked()) out.close = true;
    const ImVec4 closeCol =
        Lerp4(WithAlpha(theme.textDim, contentAlpha), WithAlpha(theme.text, contentAlpha),
              ui.closeHover);
    dl->AddLine(ImVec2(winW - 30.f, 25.f), ImVec2(winW - 20.f, 35.f),
                ImGui::GetColorU32(closeCol), 2.f);
    dl->AddLine(ImVec2(winW - 30.f, 35.f), ImVec2(winW - 20.f, 25.f),
                ImGui::GetColorU32(closeCol), 2.f);

    ImGui::SetCursorPos(ImVec2(winW - 60.f, 25.f));
    ImGui::InvisibleButton("##authMin", ImVec2(20.f, 20.f));
    HoverLerp(ui.minimizeHover, ImGui::IsItemHovered(), frame.dt);
    if (ImGui::IsItemClicked()) out.minimize = true;
    const ImVec4 minCol =
        Lerp4(WithAlpha(theme.textDim, contentAlpha), WithAlpha(theme.text, contentAlpha),
              ui.minimizeHover);
    dl->AddLine(ImVec2(winW - 55.f, 30.f), ImVec2(winW - 43.f, 30.f),
                ImGui::GetColorU32(minCol), 2.f);
    ImGui::PopStyleVar();

    if (ImGui::IsKeyPressed(ImGuiKey_Escape, false) && !checking) out.requestExit = true;

    if (submitted && !checking) out.submit = true;

    ImGui::PopStyleVar(); // alpha
    ImGui::End();
}

} // namespace nl::ui
