#include "VideoBackground.h"
#include "../Log.h"
#include "imgui.h"

#include <Windows.h>
#include <objbase.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <mferror.h>
#include <propvarutil.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>

namespace nl::ui {

namespace {

std::string LastErrorText(HRESULT hr) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "0x%08lX", static_cast<unsigned long>(hr));
    return buf;
}

} // namespace

VideoBackground::~VideoBackground() {
    Shutdown();
}

bool VideoBackground::Init(ID3D11Device* device, ID3D11DeviceContext* context,
                           const std::wstring& path) {
    if (!device || !context) return false;

    const HRESULT comHr = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    comInited_ = SUCCEEDED(comHr) || comHr == RPC_E_CHANGED_MODE;

    const HRESULT mfHr = MFStartup(MF_VERSION, MFSTARTUP_FULL);
    if (FAILED(mfHr)) {
        Log("VideoBackground: MFStartup failed {}", LastErrorText(mfHr));
        return false;
    }
    mfStarted_ = true;

    Microsoft::WRL::ComPtr<IMFAttributes> attrs;
    const HRESULT attrHr = MFCreateAttributes(&attrs, 1);
    if (SUCCEEDED(attrHr) && attrs) {
        // Enables the video processor MFT so RGB32 output is available.
        // Note: combining this with MF_SOURCE_READER_ENABLE_VIDEO_PROCESSING makes
        // MFCreateSourceReaderFromURL fail with E_INVALIDARG on current Windows.
        attrs->SetUINT32(MF_SOURCE_READER_ENABLE_ADVANCED_VIDEO_PROCESSING, TRUE);
    } else {
        Log("VideoBackground: MFCreateAttributes failed {}", LastErrorText(attrHr));
    }

    HRESULT hr = MFCreateSourceReaderFromURL(path.c_str(), attrs.Get(), &reader_);
    if (FAILED(hr)) {
        Log("VideoBackground: SourceReader(attrs) failed {} path='{}'", LastErrorText(hr),
            std::filesystem::path(path).string());
        reader_.Reset();
        hr = MFCreateSourceReaderFromURL(path.c_str(), nullptr, &reader_);
        if (FAILED(hr)) {
            Log("VideoBackground: SourceReader(no attrs) failed {}", LastErrorText(hr));
            Shutdown();
            return false;
        }
    }

    reader_->SetStreamSelection(MF_SOURCE_READER_ALL_STREAMS, FALSE);
    reader_->SetStreamSelection(MF_SOURCE_READER_FIRST_VIDEO_STREAM, TRUE);

    Microsoft::WRL::ComPtr<IMFMediaType> type;
    MFCreateMediaType(&type);
    type->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
    type->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_RGB32);

    hr = reader_->SetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, type.Get());
    if (FAILED(hr)) {
        Log("VideoBackground: SetCurrentMediaType(RGB32) failed {}", LastErrorText(hr));
        Shutdown();
        return false;
    }

    Microsoft::WRL::ComPtr<IMFMediaType> current;
    hr = reader_->GetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, &current);
    if (FAILED(hr)) {
        Log("VideoBackground: GetCurrentMediaType failed {}", LastErrorText(hr));
        Shutdown();
        return false;
    }

    UINT32 w = 0, h = 0;
    if (FAILED(MFGetAttributeSize(current.Get(), MF_MT_FRAME_SIZE, &w, &h)) || w == 0 || h == 0) {
        Log("VideoBackground: frame size unavailable");
        Shutdown();
        return false;
    }
    width_ = static_cast<int>(w);
    height_ = static_cast<int>(h);

    UINT32 stride = 0;
    if (FAILED(current->GetUINT32(MF_MT_DEFAULT_STRIDE, &stride)) || stride == 0) {
        stride = static_cast<UINT32>(width_ * 4);
    }
    stride_ = static_cast<int>(static_cast<INT32>(stride));

    PROPVARIANT var;
    PropVariantInit(&var);
    if (SUCCEEDED(reader_->GetPresentationAttribute(MF_SOURCE_READER_MEDIASOURCE, MF_PD_DURATION,
                                                    &var))) {
        durationSec_ = static_cast<double>(var.uhVal.QuadPart) / 10000000.0;
    }
    PropVariantClear(&var);
    if (durationSec_ <= 0.05) durationSec_ = 2.0;

    D3D11_TEXTURE2D_DESC desc{};
    desc.Width = static_cast<UINT>(width_);
    desc.Height = static_cast<UINT>(height_);
    desc.MipLevels = 1;
    desc.ArraySize = 1;
    desc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.Usage = D3D11_USAGE_DYNAMIC;
    desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;

    hr = device->CreateTexture2D(&desc, nullptr, &texture_);
    if (FAILED(hr)) {
        Log("VideoBackground: CreateTexture2D failed {}", LastErrorText(hr));
        Shutdown();
        return false;
    }

    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc{};
    srvDesc.Format = desc.Format;
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    srvDesc.Texture2D.MipLevels = 1;
    hr = device->CreateShaderResourceView(texture_.Get(), &srvDesc, &srv_);
    if (FAILED(hr)) {
        Log("VideoBackground: CreateShaderResourceView failed {}", LastErrorText(hr));
        Shutdown();
        return false;
    }

    device_ = device;
    context_ = context;

    Log("VideoBackground: {}x{} stride={} duration={:.2f}s", width_, height_, stride_, durationSec_);
    return true;
}

void VideoBackground::ReleaseDeviceResources() {
    srv_.Reset();
    texture_.Reset();
    device_ = nullptr;
    context_ = nullptr;
}

void VideoBackground::Shutdown() {
    pending_.Reset();
    hasPending_ = false;
    eof_ = false;
    reader_.Reset();
    ReleaseDeviceResources();
    if (mfStarted_) {
        MFShutdown();
        mfStarted_ = false;
    }
    if (comInited_) {
        CoUninitialize();
        comInited_ = false;
    }
}

bool VideoBackground::SeekToStart() {
    if (!reader_) return false;
    PROPVARIANT pos;
    PropVariantInit(&pos);
    pos.vt = VT_I8;
    pos.hVal.QuadPart = 0;
    const HRESULT hr = reader_->SetCurrentPosition(GUID_NULL, pos);
    PropVariantClear(&pos);
    if (FAILED(hr)) {
        Log("VideoBackground: SetCurrentPosition failed {}", LastErrorText(hr));
        return false;
    }
    hasPending_ = false;
    pending_.Reset();
    eof_ = false;
    return true;
}

bool VideoBackground::ReadPending() {
    if (!reader_) return false;

    DWORD flags = 0;
    LONGLONG timestamp = 0;
    Microsoft::WRL::ComPtr<IMFSample> sample;
    const HRESULT hr = reader_->ReadSample(MF_SOURCE_READER_FIRST_VIDEO_STREAM, 0, nullptr, &flags,
                                           &timestamp, &sample);

    if (FAILED(hr)) {
        Log("VideoBackground: ReadSample failed {}", LastErrorText(hr));
        eof_ = true;
        return false;
    }
    if (flags & MF_SOURCE_READERF_ENDOFSTREAM) {
        eof_ = true;
        return false;
    }
    if (!sample) return false;

    pending_ = sample;
    pendingTs_ = timestamp;
    hasPending_ = true;
    eof_ = false;
    return true;
}

void VideoBackground::Upload(const Microsoft::WRL::ComPtr<IMFSample>& sample) {
    if (!texture_ || !context_ || !sample) return;

    Microsoft::WRL::ComPtr<IMFMediaBuffer> buffer;
    if (FAILED(sample->ConvertToContiguousBuffer(&buffer)) || !buffer) return;

    BYTE* data = nullptr;
    DWORD maxLen = 0;
    if (FAILED(buffer->Lock(&data, &maxLen, nullptr)) || !data) return;

    D3D11_MAPPED_SUBRESOURCE map{};
    if (SUCCEEDED(context_->Map(texture_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &map))) {
        const int srcStride = std::abs(stride_);
        const int copyBytes = std::min({static_cast<int>(map.RowPitch), srcStride, width_ * 4});
        auto* dst = static_cast<BYTE*>(map.pData);

        for (int y = 0; y < height_; ++y) {
            const int srcRow = stride_ < 0 ? (height_ - 1 - y) : y;
            std::memcpy(dst + static_cast<size_t>(y) * map.RowPitch,
                        data + static_cast<size_t>(srcRow) * srcStride,
                        static_cast<size_t>(copyBytes));
        }
        context_->Unmap(texture_.Get(), 0);
    }

    buffer->Unlock();
}

void VideoBackground::Tick(float timeSec) {
    if (!reader_ || !texture_) return;

    const double duration = durationSec_ > 0.05 ? durationSec_ : 2.0;
    double pos = std::fmod(static_cast<double>(timeSec), duration);
    if (pos < 0.0) pos += duration;

    // Clock wrapped around (or we just started): restart the clip.
    if (lastUploadSec_ < 0.0 || pos + 0.05 < lastUploadSec_) {
        SeekToStart();
    }
    lastUploadSec_ = pos;

    if (!hasPending_ && !eof_) ReadPending();

    int guard = 0;
    while (hasPending_ && static_cast<double>(pendingTs_) / 10000000.0 <= pos + 0.002 &&
           guard++ < 4) {
        Upload(pending_);
        hasPending_ = false;
        pending_.Reset();
        if (!ReadPending()) break;
    }

    // Ended before the requested position (or no frames yet): loop.
    if (!hasPending_) {
        if (SeekToStart()) ReadPending();
    }
}

void DrawVideoCover(ImDrawList* drawList, VideoBackground& video, float winW, float winH,
                    float alpha, float darken) {
    if (!drawList) return;

    if (video.Ready() && alpha > 0.001f) {
        const float vw = video.Width();
        const float vh = video.Height();
        const float scale = std::max(winW / vw, winH / vh);
        const float dw = vw * scale;
        const float dh = vh * scale;
        const ImVec2 p0((winW - dw) * 0.5f, (winH - dh) * 0.5f);
        const ImVec2 p1(p0.x + dw, p0.y + dh);
        const int a = static_cast<int>(std::clamp(alpha, 0.f, 1.f) * 255.f);
        drawList->AddImage(reinterpret_cast<ImTextureID>(video.Srv()), p0, p1, ImVec2(0, 0),
                           ImVec2(1, 1), IM_COL32(255, 255, 255, a));
    } else {
        drawList->AddRectFilled(ImVec2(0, 0), ImVec2(winW, winH), IM_COL32(0, 3, 3, 255));
    }

    if (darken > 0.f) {
        const int a = static_cast<int>(std::clamp(darken, 0.f, 1.f) * 255.f);
        drawList->AddRectFilled(ImVec2(0, 0), ImVec2(winW, winH), IM_COL32(0, 0, 0, a));
    }
}

} // namespace nl::ui
