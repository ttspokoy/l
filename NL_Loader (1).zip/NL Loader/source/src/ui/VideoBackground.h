#pragma once
#include <Windows.h>
#include <d3d11.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <wrl/client.h>
#include <string>
#include "imgui.h"

namespace nl::ui {

// Decodes a video file with Windows Media Foundation and keeps uploading frames
// into a dynamic D3D11 texture. Used as the animated splash/auth background.
class VideoBackground {
  public:
    VideoBackground() = default;
    VideoBackground(const VideoBackground&) = delete;
    VideoBackground& operator=(const VideoBackground&) = delete;
    ~VideoBackground();

    bool Init(ID3D11Device* device, ID3D11DeviceContext* context, const std::wstring& path);
    void Shutdown();

    // Advances playback to timeSec (looping) and updates the GPU texture.
    void Tick(float timeSec);

    [[nodiscard]] ID3D11ShaderResourceView* Srv() const { return srv_.Get(); }
    [[nodiscard]] bool Ready() const { return srv_ != nullptr && width_ > 0 && height_ > 0; }
    [[nodiscard]] float Width() const { return static_cast<float>(width_); }
    [[nodiscard]] float Height() const { return static_cast<float>(height_); }

  private:
    bool ReadPending();
    bool SeekToStart();
    void Upload(const Microsoft::WRL::ComPtr<IMFSample>& sample);
    void ReleaseDeviceResources();

    Microsoft::WRL::ComPtr<IMFSourceReader> reader_;
    Microsoft::WRL::ComPtr<ID3D11Texture2D> texture_;
    Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> srv_;
    ID3D11Device* device_ = nullptr;
    ID3D11DeviceContext* context_ = nullptr;

    int width_ = 0;
    int height_ = 0;
    int stride_ = 0;
    double durationSec_ = 0.0;
    double lastUploadSec_ = -1.0;

    Microsoft::WRL::ComPtr<IMFSample> pending_;
    LONGLONG pendingTs_ = 0;
    bool hasPending_ = false;
    bool eof_ = false;
    bool mfStarted_ = false;
    bool comInited_ = false;
};

void DrawVideoCover(ImDrawList* drawList, VideoBackground& video, float winW, float winH,
                    float alpha, float darken);

} // namespace nl::ui
